package com.myapp.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.myapp.dao.ProductDAO;
import com.myapp.model.Product;
import com.myapp.utility.DbConnect;

public class ProductRepository implements ProductDAO {
	DbConnect db;
	Connection con;
	
	public ProductRepository() {
		db = new DbConnect();
        con = db.getConnection();
	}
	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
			Connection con=null;
			try {
			  con = db.getConnection();
				System.out.println("add called from productrepo");
				PreparedStatement stmt = con.prepareStatement(
						"INSERT INTO products (ProductID, ProdName,ProdPrice)"
								+ " values (?, ?, ?)");
				stmt.setInt(1, product.getPrdId());
				stmt.setString(2, product.getProdName());
				stmt.setFloat(3, product.getPrdPrice());
				stmt.executeUpdate();
				con.close();
				System.out.println("record added");
				return true;
			} catch (SQLException e) {
				System.out.println(e);
			}finally {
				
			}
			
			return false;	
		}
	

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
