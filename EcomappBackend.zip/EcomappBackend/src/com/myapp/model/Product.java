package com.myapp.model;

public class Product {
	private int prdId;
	private String prodName;
	private float prdPrice;
	
	public Product() {
		
	}
	
	public Product(int prdId, String prodName, float prdPrice) {
		super();
		this.prdId = prdId;
		this.prodName = prodName;
		this.prdPrice = prdPrice;
	}
	
	public int getPrdId() {
		return prdId;
	}
	public void setPrdId(int prdId) {
		this.prdId = prdId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public float getPrdPrice() {
		return prdPrice;
	}
	public void setPrdPrice(float prdPrice) {
		this.prdPrice = prdPrice;
	}
	
	
}
