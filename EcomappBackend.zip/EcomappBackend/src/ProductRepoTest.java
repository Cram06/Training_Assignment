import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.After;
import org.junit.Test;

import com.myapp.model.Product;
import com.myapp.repository.ProductRepository;


public class ProductRepoTest {
	ProductRepository productrepository = new ProductRepository();

	@Test
	public void testDBConnection() {
		String url= "jdbc:oracle:thin:localhost:1521:xe" ;
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "hr", "password");
			System.out.println("We are connected tothe db");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT productid,prodname,prodprice FROM hr.products");
			while (rs.next()) {
				int prodid = rs.getInt("productid");
				String prodname = rs.getString("prodname");
				Float prodprice = rs.getFloat("prodprice");
				System.out.println(prodid + " " + prodname + " " + prodprice);
				}			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void addProductTest() {
		Product product = new Product();
		product.setPrdId(111);
		product.setProdName("computer");
		product.setPrdPrice(20000.00f);
		
		assertEquals("Failed to add the product", true, productrepository.addProduct(product));
	}
		
		
		@After
		public void tearDown() throws Exception {
		}
}
